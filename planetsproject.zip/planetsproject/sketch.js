let planets = []; // Global array to store all planets
let sunR; // Sun radius

function setup() {
  createCanvas(windowWidth, windowHeight);
  sunR = width / 8; // Sun radius (adjusted for size)
}

function draw() {
  background(0); // Black background for space

  // Draw the sun
  fill(255, 255, 0);
  circle(width / 2, height / 2, sunR);

  // Loop through all planets in the array
  for (let planet of planets) {
    planet.action();
  }
}

// Function to add a planet on regular click
function mouseClicked() {
  if (keyIsDown(SHIFT)) {
    if (planets.length > 0) {
      planets[planets.length - 1].createMoon(); // Add moon to the last planet if SHIFT is held
    }
  } else {
    planets.push(new Planet(width / 2 - sunR, [random(255), random(255), random(255)], random(1, 3))); // Create a new planet
  }
}

// Planet class
class Planet {
  constructor(x, c, xSpeed) {
    this.x = x; // Planet's x position
    this.y = height / 2; // Planet's y position (fixed in the center)
    this.r = sunR / 10; // Smaller radius of the planet
    this.c = c; // Color of the planet
    this.direction = xSpeed; // Direction of movement
    this.xSpeed = xSpeed; // Speed of movement
    this.moons = []; // Array to hold moons of the planet
    this.orbitRadius = sunR + random(50, 150); // Orbit radius for the planet
  }

  // Method to move the planet on the x-axis
  move() {
    this.x += this.direction; // Update position based on direction

    // Reverse direction at orbit bounds
    if (this.x <= width / 2 - this.orbitRadius) {
      this.direction = this.xSpeed; // Move right
    } else if (this.x >= width / 2 + this.orbitRadius) {
      this.direction = -this.xSpeed; // Move left
    }
  }

  // Method to display the planet
  display() {
    let sunLeftEdge = width / 2 - sunR / 2; // Left edge of the sun
    let sunRightEdge = width / 2 + sunR / 2; // Right edge of the sun

    // Check if the planet is completely behind the sun
    if (this.x - this.r > sunLeftEdge && this.x + this.r < sunRightEdge) {
      // The planet is behind the sun, do not draw it
      return;
    }

    // If part of the planet is visible, draw it
    fill(this.c);
    circle(this.x, this.y, this.r);

    // Draw moons behind or in front of the planet
    for (let moon of this.moons) {
      moon.display();
    }
  }

  // Add a moon to the planet
  createMoon() {
    let moon = new Moon(this, random(20, 50), random(1, 3)); // Attach moon to this planet
    this.moons.push(moon); // Add the new moon to the planet's moons array
  }

  // Action that combines all planet's functions
  action() {
    this.move();
    this.display();
    // Random chance to modify orbit or color
    if (random(1) < 0.01) this.increaseOrbit();
    if (random(1) < 0.01) this.decreaseOrbit();
    if (random(1) < 0.01) this.changeColor();
  }

  // Increase orbit radius
  increaseOrbit() {
    this.orbitRadius += 5;
  }

  // Decrease orbit radius (but not too small)
  decreaseOrbit() {
    if (this.orbitRadius > 50) this.orbitRadius -= 5;
  }

  // Change the planet's color
  changeColor() {
    this.c = [random(255), random(255), random(255)];
  }
}

// Moon class
class Moon {
  constructor(planet, orbitRadius, speed) {
    this.planet = planet; // Reference to the planet this moon orbits
    this.orbitRadius = orbitRadius; // Distance from the planet
    this.speed = speed; // Speed of the moon's orbit
    this.offset = random(-this.orbitRadius, this.orbitRadius); // Random offset for horizontal oscillation
    this.r = planet.r / 2; // Radius of the moon
    this.c = [random(100, 200), random(100, 200), random(100, 200)]; // Greyscale color
  }

  // Move the moon in its orbit (horizontal only)
  move() {
    this.offset += this.speed * 0.1; // Increment horizontal offset
    if (abs(this.offset) > this.orbitRadius) {
      this.speed *= -1; // Reverse direction at orbit bounds
    }
  }

  // Display the moon
  display() {
    this.move(); // Update position
    let x = this.planet.x + this.offset; // X position relative to planet
    let y = this.planet.y; // Y position remains fixed relative to planet

    // Draw the moon only if the planet is not behind the sun
    fill(this.c);
    circle(x, y, this.r);
  }
}
